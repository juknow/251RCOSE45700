autor: Pavel Kutejnikov

game: Tzakol in Exile
https://store.steampowered.com/app/1764840/Tzakol_in_Exile/

license: cc0 / public domain